import pygame

# A basic 2D topdown camera.
class Camera:
    def __init__(self, game, screen, resolution):
        self.game = game
        self.original_width = screen.get_width() 
        self.original_height = screen.get_height()
        self.set_resolution(resolution)
        
    # Set the resolution of the screen, not window size.
    def set_resolution(self, resolution):
        self.resolution = resolution
        self.update_camera_props()
        
    # Internal, updates camera properties
    def update_camera_props(self):
        self.display = pygame.Surface(self.resolution)
        self.camera_width = self.display.get_width()
        self.camera_height = self.display.get_height()
        self.camera_rect = pygame.FRect(0, 0, self.camera_width, self.camera_height)
        
    # Set the camera position
    def set_camera_position(self, position):
        self.camera_rect.x = position[0] - self.camera_width / 2
        self.camera_rect.y = position[1] - self.camera_height / 2
        
    # Move the camera
    def move_camera(self, movement):
        self.camera_rect.x += movement[0]
        self.camera_rect.y += movement[1]

