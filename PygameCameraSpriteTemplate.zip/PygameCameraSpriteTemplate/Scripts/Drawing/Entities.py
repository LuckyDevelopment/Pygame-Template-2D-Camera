import pygame
import random

# An entity with position, size and velocity.
class Entity:
    # Constructor
    def __init__(self, game, entity_type, position, size):
        self.game = game
        self.type = entity_type
        self.velocity = [0, 0]
        self.zIndex = 0
        self.rect = pygame.FRect(position[0], position[1], size[0], size[1])
     
    
    # Compares two entities based on zIndex.
    def __lt__(self, other):
        return self.zIndex < other.zIndex
    
    # update the entity every frame.
    def update(self, delta_time):
        pass
    
    # render the entity every frame.
    def render(self, surface, offset, bounds):
        pass
    
    
    
    
    
    
# A entity that is an image.
class ImageEntity(Entity):
    # Constructor
    def __init__(self, game, position, size, imageFile):
        super().__init__(game, "ImageEntity", position, size)
        splitPath = imageFile.split("/")
        self.image = pygame.transform.scale(self.game.assets[splitPath[0]][splitPath[1]], (size[0], size[1]))
    
    # update entity every frame.
    def update(self, delta_time):
        super().update(delta_time)
        
    # render entity every frame.
    def render(self, surface, offset):
        surface.blit(self.image, (offset.x, offset.y))





# A basic rectangle class
class BasicRect(Entity):
    # Constructor
    def __init__(self, game, position, size, color):
        super().__init__(game, "BasicRect", position, size)
        self.color = tuple(color)
    
    # update entity every frame
    def update(self, delta_time):
        super().update(delta_time)
        
    # render entity every frame
    def render(self, surface, offset):
        pygame.draw.rect(surface, self.color, (offset.x, offset.y, self.size[0], self.size[1]))
    
    
    
    
        
            
# A basic circle class
class BasicCircle(Entity):
    # Constructor
    def __init__(self, game, position, radius, color):
        super().__init__(game, "BasicCircle", position, (radius * 2,  radius * 2))
        self.color = tuple(color)
        self.radius = radius
        
    # update entity every frame
    def update(self, delta_time):
        super().update(delta_time)
        
    # render entity every frame
    def render(self, surface, offset):
        pygame.draw.circle(surface, self.color, (offset.x , offset.y), self.radius)
        