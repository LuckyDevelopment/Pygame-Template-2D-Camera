import pygame

# Constants
BASE_IMAGE_PATH = "data/images/"

# Loads an image based off a normal path
def load_image(path):
    image = pygame.image.load(BASE_IMAGE_PATH + path).convert_alpha()
    return image