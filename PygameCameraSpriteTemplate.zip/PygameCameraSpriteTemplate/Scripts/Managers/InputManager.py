import pygame

# Handles all inputs.
class InputManager:
    def __init__(self, game):
        self.game = game
        self.held_keys = set()
    
    # Call every frame to update keys
    def update(self):
        # Handle key events
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                self.game.game_running = False
                break
            if event.type == pygame.KEYDOWN:
                if not event.key in self.held_keys:
                    self.held_keys.add(event.key)
            if event.type == pygame.KEYUP:
                if event.key in self.held_keys:
                    self.held_keys.remove(event.key)

    # Returns if the key is being held.
    def is_key_down(self, key):
        return key in self.held_keys
    
    # Returns if this key is held down on this frame.
    def is_key_pressed(self, key):
        if key in self.held_keys:
            self.held_keys.remove(key)
            return True
        return False
    
    # Get mouse position from center of screen.
    def get_mouse_pos(self, camera):
        position = pygame.mouse.get_pos()
        return (position[0] - camera.original_width / 2, position[1] - camera.original_height / 2)
    
    # Get mouse position from top left.
    def get_mouse_pos_normal(self):
        return pygame.mouse.get_pos()
    
    # Return normalized mouse position from the center of the screen.
    def get_normalized_mouse_pos(self, camera):
        position = pygame.mouse.get_pos()
        return ((position[0] - camera.original_width / 2)/ camera.original_width * 2, (position[1] - camera.original_height / 2)/ camera.original_height * 2)