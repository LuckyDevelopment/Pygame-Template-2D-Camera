import pygame
import bisect

# Adding and removing entities and also rendering them
class EntityManager:
    def __init__(self):
        self.entities = list()
        
    # Add an entity to the world
    def add_entity(self, entity):
        bisect.insort(self.entities, entity)
        
    # Remove an entity from the world
    def remove_entity(self, entity):
        self.entities.remove(entity)
        
    # Update all entities
    def update_entities(self, deltaTime):
        for entity in self.entities:
            entity.update(deltaTime)
        
    # Renders all entites onto a surface.
    def render_entities(self, surface, camera):
        for entity in self.entities:
            offset_rect = entity.rect.move(-camera.camera_rect.x, -camera.camera_rect.y)
            
            # Check if entity is off screen, works badly for circles, should use image rects always.
            if not (offset_rect.y + entity.rect.size[1] < 0 or offset_rect.y > camera.camera_height or offset_rect.x + entity.rect.size[0] < 0 or offset_rect.x > camera.camera_width):
                 entity.render(surface, offset_rect)
           