import pygame
import pygame.freetype
import Scripts.Core.Utils as Utils

# Holds and does most things with assets in the game.
class AssetManager:
    def __init__(self):
        pass
    
    # Stores all assets for the game
    def load_assets(self):
        return {
            'images': {
                'player': Utils.load_image('player.png'),
                'player2': Utils.load_image('player2.png')
            },
            'fonts': {
                'default': pygame.freetype.Font("data/fonts/Minecraft.ttf", 35)
            }
        }