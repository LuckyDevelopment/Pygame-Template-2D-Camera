import pygame
import sys
import Scripts.Drawing.Entities as Entities
import Scripts.Managers.AssetManager as AssetManager
import Scripts.Managers.EntityManager as EntityManager
import Scripts.Managers.InputManager as InputManager
import Scripts.Drawing.Camera as Camera
import math
import random

class Game:
    # Constructor
    def __init__(self):
        # Create new window
        pygame.init()
        pygame.display.set_caption("Test Window")
        
        # Create screen and variables.
        self.screen = pygame.display.set_mode((800, 600)) # Window Size
        self.camera = Camera.Camera(self, self.screen, (200, 150)) # Target Resolution (Scaled to Window Size)
        
        self.target_frame_rate = 60
        self.current_frame = 0
        self.clock = pygame.time.Clock()
        self.game_running = True
        self.delta_time = float(0.01)
        self.elapsed_time = 0
        
        # Create managers and load assets
        self.entity_manager = EntityManager.EntityManager()
        self.assets = AssetManager.AssetManager().load_assets()
        self.input_manager = InputManager.InputManager(self)
        
        ## EXAMPLE CREATE OBJECTS ================================================================================= 
        
        # A player
        self.player = Entities.BasicCircle(self, (100, 50), 4, (0, 0, 0))
        self.player.zIndex = 500
        self.entity_manager.add_entity(self.player)
        
        ball = Entities.ImageEntity(self, (50, 50), (20, 20), "images/player")
        self.entity_manager.add_entity(ball)
        
        ball2 = Entities.ImageEntity(self, (60, 50), (20, 20), "images/player2")
        self.entity_manager.add_entity(ball2)
        
        # =================================================================================
        
        
        
    # Called every frame to update game.
    def update(self):
    
        while self.game_running:
            #Background
            self.camera.display.fill((255, 255, 255))
            
            # Handle events
            self.input_manager.update()
        
            # EXAMPLE OF MOVING A PLAYER =================================================================================
            speed = 75.0 * self.delta_time
            mousePosition = self.input_manager.get_normalized_mouse_pos(self.camera) 
            self.player.rect.x += mousePosition[0]* speed
            self.player.rect.y += mousePosition[1]* speed

            # EXAMPLE MOVE CAMERA  ================================================================================= 
            self.camera.set_camera_position((self.player.rect.x, self.player.rect.y))    
            # =================================================================================
            
            # Render entities
            self.entity_manager.update_entities(self.delta_time)
            self.entity_manager.render_entities(self.camera.display, self.camera)

            # Update buffers and delta_time
            self.delta_time = max(0.000001, min(0.2, self.clock.tick(self.target_frame_rate) / 1000))
            self.screen.blit(pygame.transform.scale(self.camera.display, self.screen.get_size()), (0, 0))
            pygame.display.update()
            
            # Update frame and elapsed time
            self.current_frame += 1
            self.elapsed_time += self.delta_time
        
        # Quit game
        pygame.quit()
        sys.exit()
            
            
Game().update()